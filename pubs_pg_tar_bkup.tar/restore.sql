--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.9
-- Dumped by pg_dump version 14.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pubs;
--
-- Name: pubs; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE pubs WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_India.1252';


ALTER DATABASE pubs OWNER TO postgres;

\connect pubs

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dbo; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA dbo;


ALTER SCHEMA dbo OWNER TO postgres;

--
-- Name: empid; Type: TYPE; Schema: dbo; Owner: postgres
--

CREATE TYPE dbo.empid AS (
	empid character(9)
);


ALTER TYPE dbo.empid OWNER TO postgres;

--
-- Name: id; Type: TYPE; Schema: dbo; Owner: postgres
--

CREATE TYPE dbo.id AS (
	id character varying(11)
);


ALTER TYPE dbo.id OWNER TO postgres;

--
-- Name: tid; Type: TYPE; Schema: dbo; Owner: postgres
--

CREATE TYPE dbo.tid AS (
	tid character varying(6)
);


ALTER TYPE dbo.tid OWNER TO postgres;

--
-- Name: byroyalty(integer); Type: PROCEDURE; Schema: dbo; Owner: postgres
--

CREATE PROCEDURE dbo.byroyalty(IN p_percentage integer, OUT cur refcursor)
    LANGUAGE plpgsql
    AS $$
BEGIN
open cur for select au_id from dbo.titleauthor
where titleauthor.royaltyper = p_percentage;


END;
$$;


ALTER PROCEDURE dbo.byroyalty(IN p_percentage integer, OUT cur refcursor) OWNER TO postgres;

--
-- Name: reptq1(); Type: PROCEDURE; Schema: dbo; Owner: postgres
--

CREATE PROCEDURE dbo.reptq1(OUT cur refcursor)
    LANGUAGE plpgsql
    AS $$
BEGIN
open cur for select
	case when grouping(pub_id) = 1 then 'ALL' else pub_id end as pub_id,
	avg(price) as avg_price
from dbo.titles
where price is NOT NULL
group by rollup (pub_id)
order by pub_id;


END;
$$;


ALTER PROCEDURE dbo.reptq1(OUT cur refcursor) OWNER TO postgres;

--
-- Name: reptq2(); Type: PROCEDURE; Schema: dbo; Owner: postgres
--

CREATE PROCEDURE dbo.reptq2(OUT cur refcursor)
    LANGUAGE plpgsql
    AS $$
BEGIN
open cur for select
	case when grouping(type) = 1 then 'ALL' else type end as type,
	case when grouping(pub_id) = 1 then 'ALL' else pub_id end as pub_id,
	avg(ytd_sales) as avg_ytd_sales
from dbo.titles
where pub_id is NOT NULL
group by rollup (pub_id, type);


END;
$$;


ALTER PROCEDURE dbo.reptq2(OUT cur refcursor) OWNER TO postgres;

--
-- Name: reptq3(money, money, character); Type: PROCEDURE; Schema: dbo; Owner: postgres
--

CREATE PROCEDURE dbo.reptq3(IN p_lolimit money, IN p_hilimit money, IN p_type character, OUT cur refcursor)
    LANGUAGE plpgsql
    AS $$
BEGIN
open cur for select
	case when grouping(pub_id) = 1 then 'ALL' else pub_id end as pub_id,
	case when grouping(type) = 1 then 'ALL' else type end as type,
	count(title_id) as cnt
from dbo.titles
where price >p_lolimit AND price <p_hilimit AND type = p_type OR type LIKE '%cook%'
group by rollup (pub_id, type);


END;
$$;


ALTER PROCEDURE dbo.reptq3(IN p_lolimit money, IN p_hilimit money, IN p_type character, OUT cur refcursor) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: authors; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.authors (
    au_id character varying(20) NOT NULL,
    au_lname character varying(40) NOT NULL,
    au_fname character varying(20) NOT NULL,
    phone character(12) DEFAULT 'UNKNOWN'::bpchar NOT NULL,
    address character varying(40),
    city character varying(20),
    state character(2),
    zip character(5),
    contract character(10) NOT NULL
);


ALTER TABLE dbo.authors OWNER TO postgres;

--
-- Name: discounts; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.discounts (
    discounttype character varying(40) NOT NULL,
    stor_id character(4),
    lowqty smallint,
    highqty smallint,
    discount numeric(4,2) NOT NULL
);


ALTER TABLE dbo.discounts OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.employee (
    emp_id character(9) NOT NULL,
    fname character varying(20) NOT NULL,
    minit character(1),
    lname character varying(30) NOT NULL,
    job_id smallint DEFAULT 1 NOT NULL,
    job_lvl smallint DEFAULT 10,
    pub_id character(4) DEFAULT '9952'::bpchar NOT NULL,
    hire_date timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE dbo.employee OWNER TO postgres;

--
-- Name: jobs; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.jobs (
    job_id smallint NOT NULL,
    job_desc character varying(50) DEFAULT 'New Position - title not formalized yet'::character varying NOT NULL,
    min_lvl smallint NOT NULL,
    max_lvl smallint NOT NULL,
    CONSTRAINT jobs_max_lvl_check CHECK ((max_lvl <= 250)),
    CONSTRAINT jobs_min_lvl_check CHECK ((min_lvl >= 10))
);


ALTER TABLE dbo.jobs OWNER TO postgres;

--
-- Name: pub_info; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pub_info (
    pub_id character(4) NOT NULL,
    logo bytea,
    pr_info text
);


ALTER TABLE dbo.pub_info OWNER TO postgres;

--
-- Name: publishers; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.publishers (
    pub_id character(4) NOT NULL,
    pub_name character varying(40),
    city character varying(20),
    state character(2),
    country character varying(30) DEFAULT 'USA'::character varying
);


ALTER TABLE dbo.publishers OWNER TO postgres;

--
-- Name: roysched; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.roysched (
    title_id character varying(6) NOT NULL,
    lorange integer,
    hirange integer,
    royalty integer
);


ALTER TABLE dbo.roysched OWNER TO postgres;

--
-- Name: sales; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.sales (
    stor_id character(4) NOT NULL,
    ord_num character varying(20) NOT NULL,
    ord_date timestamp(3) without time zone NOT NULL,
    qty smallint NOT NULL,
    payterms character varying(12) NOT NULL,
    title_id character varying(6) NOT NULL
);


ALTER TABLE dbo.sales OWNER TO postgres;

--
-- Name: stores; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.stores (
    stor_id character(4) NOT NULL,
    stor_name character varying(40),
    stor_address character varying(40),
    city character varying(20),
    state character(2),
    zip character(5)
);


ALTER TABLE dbo.stores OWNER TO postgres;

--
-- Name: titleauthor; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.titleauthor (
    au_id character varying(11) NOT NULL,
    title_id character varying(6) NOT NULL,
    au_ord smallint,
    royaltyper integer
);


ALTER TABLE dbo.titleauthor OWNER TO postgres;

--
-- Name: titles; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.titles (
    title_id character varying(6) NOT NULL,
    title character varying(80) NOT NULL,
    type character(12) DEFAULT 'UNDECIDED'::bpchar NOT NULL,
    pub_id character(4),
    price money,
    advance money,
    royalty integer,
    ytd_sales integer,
    notes character varying(200),
    pubdate timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE dbo.titles OWNER TO postgres;

--
-- Name: titleview; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.titleview AS
 SELECT titles.title,
    titleauthor.au_ord,
    authors.au_lname,
    titles.price,
    titles.ytd_sales,
    titles.pub_id
   FROM dbo.authors,
    dbo.titles,
    dbo.titleauthor
  WHERE (((authors.au_id)::text = (titleauthor.au_id)::text) AND ((titles.title_id)::text = (titleauthor.title_id)::text));


ALTER TABLE dbo.titleview OWNER TO postgres;

--
-- Data for Name: authors; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.authors (au_id, au_lname, au_fname, phone, address, city, state, zip, contract) FROM stdin;
\.
COPY dbo.authors (au_id, au_lname, au_fname, phone, address, city, state, zip, contract) FROM '$$PATH$$/3403.dat';

--
-- Data for Name: discounts; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.discounts (discounttype, stor_id, lowqty, highqty, discount) FROM stdin;
\.
COPY dbo.discounts (discounttype, stor_id, lowqty, highqty, discount) FROM '$$PATH$$/3413.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.employee (emp_id, fname, minit, lname, job_id, job_lvl, pub_id, hire_date) FROM stdin;
\.
COPY dbo.employee (emp_id, fname, minit, lname, job_id, job_lvl, pub_id, hire_date) FROM '$$PATH$$/3404.dat';

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.jobs (job_id, job_desc, min_lvl, max_lvl) FROM stdin;
\.
COPY dbo.jobs (job_id, job_desc, min_lvl, max_lvl) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: pub_info; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pub_info (pub_id, logo, pr_info) FROM stdin;
\.
COPY dbo.pub_info (pub_id, logo, pr_info) FROM '$$PATH$$/3406.dat';

--
-- Data for Name: publishers; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.publishers (pub_id, pub_name, city, state, country) FROM stdin;
\.
COPY dbo.publishers (pub_id, pub_name, city, state, country) FROM '$$PATH$$/3407.dat';

--
-- Data for Name: roysched; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.roysched (title_id, lorange, hirange, royalty) FROM stdin;
\.
COPY dbo.roysched (title_id, lorange, hirange, royalty) FROM '$$PATH$$/3408.dat';

--
-- Data for Name: sales; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.sales (stor_id, ord_num, ord_date, qty, payterms, title_id) FROM stdin;
\.
COPY dbo.sales (stor_id, ord_num, ord_date, qty, payterms, title_id) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: stores; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.stores (stor_id, stor_name, stor_address, city, state, zip) FROM stdin;
\.
COPY dbo.stores (stor_id, stor_name, stor_address, city, state, zip) FROM '$$PATH$$/3410.dat';

--
-- Data for Name: titleauthor; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.titleauthor (au_id, title_id, au_ord, royaltyper) FROM stdin;
\.
COPY dbo.titleauthor (au_id, title_id, au_ord, royaltyper) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: titles; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.titles (title_id, title, type, pub_id, price, advance, royalty, ytd_sales, notes, pubdate) FROM stdin;
\.
COPY dbo.titles (title_id, title, type, pub_id, price, advance, royalty, ytd_sales, notes, pubdate) FROM '$$PATH$$/3412.dat';

--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (job_id);


--
-- Name: employee pk_emp_id; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.employee
    ADD CONSTRAINT pk_emp_id PRIMARY KEY (emp_id);


--
-- Name: stores upk_storeid; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.stores
    ADD CONSTRAINT upk_storeid PRIMARY KEY (stor_id);


--
-- Name: authors upkcl_auidind; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.authors
    ADD CONSTRAINT upkcl_auidind PRIMARY KEY (au_id);


--
-- Name: publishers upkcl_pubind; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.publishers
    ADD CONSTRAINT upkcl_pubind PRIMARY KEY (pub_id);


--
-- Name: pub_info upkcl_pubinfo; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.pub_info
    ADD CONSTRAINT upkcl_pubinfo PRIMARY KEY (pub_id);


--
-- Name: sales upkcl_sales; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.sales
    ADD CONSTRAINT upkcl_sales PRIMARY KEY (stor_id, ord_num, title_id);


--
-- Name: titleauthor upkcl_taind; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.titleauthor
    ADD CONSTRAINT upkcl_taind PRIMARY KEY (au_id, title_id);


--
-- Name: titles upkcl_titleidind; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.titles
    ADD CONSTRAINT upkcl_titleidind PRIMARY KEY (title_id);


--
-- Name: discounts discounts_stor_id_fkey; Type: FK CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.discounts
    ADD CONSTRAINT discounts_stor_id_fkey FOREIGN KEY (stor_id) REFERENCES dbo.stores(stor_id);


--
-- Name: employee employee_job_id_fkey; Type: FK CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.employee
    ADD CONSTRAINT employee_job_id_fkey FOREIGN KEY (job_id) REFERENCES dbo.jobs(job_id);


--
-- Name: employee employee_pub_id_fkey; Type: FK CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.employee
    ADD CONSTRAINT employee_pub_id_fkey FOREIGN KEY (pub_id) REFERENCES dbo.publishers(pub_id);


--
-- Name: pub_info pub_info_pub_id_fkey; Type: FK CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.pub_info
    ADD CONSTRAINT pub_info_pub_id_fkey FOREIGN KEY (pub_id) REFERENCES dbo.publishers(pub_id);


--
-- Name: roysched roysched_title_id_fkey; Type: FK CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.roysched
    ADD CONSTRAINT roysched_title_id_fkey FOREIGN KEY (title_id) REFERENCES dbo.titles(title_id);


--
-- Name: sales sales_stor_id_fkey; Type: FK CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.sales
    ADD CONSTRAINT sales_stor_id_fkey FOREIGN KEY (stor_id) REFERENCES dbo.stores(stor_id);


--
-- Name: sales sales_title_id_fkey; Type: FK CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.sales
    ADD CONSTRAINT sales_title_id_fkey FOREIGN KEY (title_id) REFERENCES dbo.titles(title_id);


--
-- Name: titleauthor titleauthor_au_id_fkey; Type: FK CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.titleauthor
    ADD CONSTRAINT titleauthor_au_id_fkey FOREIGN KEY (au_id) REFERENCES dbo.authors(au_id);


--
-- Name: titleauthor titleauthor_title_id_fkey; Type: FK CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.titleauthor
    ADD CONSTRAINT titleauthor_title_id_fkey FOREIGN KEY (title_id) REFERENCES dbo.titles(title_id);


--
-- Name: titles titles_pub_id_fkey; Type: FK CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.titles
    ADD CONSTRAINT titles_pub_id_fkey FOREIGN KEY (pub_id) REFERENCES dbo.publishers(pub_id);


--
-- PostgreSQL database dump complete
--

